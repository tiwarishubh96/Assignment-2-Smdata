import { LightningElement, track, wire, api } from 'lwc';
import accountGroupData from '@salesforce/apex/AccountandAccountGroupData.accountGroupData';
import relatedAccountswithAccountGroup from 'c/relatedAccountswithAccountGroup';

export default class AccountGroupLWC extends LightningElement {
  @track data = [];
  @track columns = [
    

    { 
            label: 'Name', fieldName: 'Name', type: 'button',
            
            typeAttributes: { 
                label: { fieldName: 'Name' }, 
                variant: "base",
                name : 'ViewAccounts'
            } 
        }
    ];

  @track page = 1;
  @api pageSize; // Number of records to be displayed in the page
  @track totalRecords = 0;
  @track totalPages = 0;
  @track paginatedData = []; // To store sliced data

  @wire(accountGroupData)
  acctGroups({ error, data }) {
    if (data) {
      this.data = data;
      this.totalRecords = data.length;
      this.totalPages = Math.ceil(this.totalRecords / this.pageSize);
      this.updatePaginatedData();
    } else if (error) {
      console.error('Error fetching accounts:', error);
    }
  }

  /**
   * @description Boolean to disable previous button
   */
  get _disablePrevious(){
    return this.page === 1 ? true : false;
  }

  /**
   * @description Boolean to disable next button
   */
  get _disableNext(){
    return this.page === this.totalPages ? true : false;
  }

  updatePaginatedData() {
    const startIndex = (this.page - 1) * this.pageSize; // Calculates the start index of paginated data
    const endIndex = startIndex + this.pageSize; // Calculates the end index of paginated data
    this.paginatedData = this.data.slice(startIndex, endIndex);
  }

  /**
   * @description Handles the previous button click
   */
  handlePrevious() {
    if (this.page > 1) {
      this.page--;
      this.updatePaginatedData();
    }
  }

  /**
   * @description Handles the next button click
   */
  handleNext() {
    if (this.page < this.totalPages) {
      this.page++;
      this.updatePaginatedData();
    }
  }

  handleRowAction( event ) {
        
      //  let listAccountData;
        const selectedValue = event.detail.row.Id;
        const actionName = event.detail.action.name;
        console.log(
            'selectedValue is',
            JSON.stringify( selectedValue )
        );
        console.log(
            'actionName is',
            JSON.stringify( actionName )
        );

        if ( actionName === "ViewAccounts" ) {
            
       /*    this.data.forEach(function(accGroupData){
    if(accGroupData.Id==selectedValue)
  listAccountData=accGroupData.Accounts__r;
});*/

            console.log( 
                JSON.stringify( this.data)
            );

         /*   console.log( 
                JSON.stringify( listAccountData)
            );*/
            const result = relatedAccountswithAccountGroup.open( {
                size: 'Medium',
                description: 'Accounts related with Account Group',
                accGroupId: selectedValue,
                rowLimit: this.pageSize
            } );
            console.log(
                'result is',
                JSON.stringify( result )
            );

        }

    }
}
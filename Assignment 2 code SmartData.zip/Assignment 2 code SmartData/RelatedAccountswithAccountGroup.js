import { api, track } from 'lwc';
import LightningModal from 'lightning/modal';
import accountData from '@salesforce/apex/AccountandAccountGroupData.accountData';

export default class RelatedAccountswithAccountGroup extends LightningModal  {

@api accGroupId;
@api rowLimit;
@track listAccountslazyLoad;
@track rowOffset=0;

@track isLoading=false;

columns = [ 
    { label: 'Name', fieldName: 'Name' }, 
    { label: 'Account Group', fieldName: 'AcctGroupName__c' }
];

handleClose() {

    this.close(
        'Closed'
    );
    
}

async connectedCallback(){
   
this.listAccountslazyLoad = await this.loadData();
this.isLoading = true;
    
}

async loadData(){

let result;
    try {
        result = await accountData({accGroupId: this.accGroupId, rows:this.rowLimit  , offset: this.rowOffset});
        
        
        console.log(JSON.stringify(result ));
    } catch (error) {
        this.accounts = undefined;
    }
    finally{
        return result;
    }
}

async loadMoreData(event){

console.log('in loadmoredata');
    
    this.isLoading = true;

    this.rowOffset = this.rowOffset + this.rowLimit;

    let newAccounts = await this.loadData();
    this.listAccountslazyLoad = [...this.listAccountslazyLoad, ...newAccounts];

    target.isLoading = false;
}

}  